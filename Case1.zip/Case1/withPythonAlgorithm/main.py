import sys
import time
import os
from typing import List, Dict, Tuple, Any

class MFI:
    def __init__(self):
        self.chromosome = []
        self.number = 0
        self.support = 0.0
        self.progress = 0
        self.times = 0.0
        self.ItemSets = []
        self.ItemSetsStr = []
        self.root = 0

# 全局变量
MaximalPopulationMat = []
MaximalPopulationSize = 0
MaximalPopulation = []

MaxItemID = MinItemID = TransLengthMax = TransLengthMin = 0
TransLengthMean = 0.0
TransSetReducedRAM = []
SupportThreshold = 0.0
TransSetDimensionReduced = TransNum = TransNumReduced = 0

def GetTransSetSize(TransSet: str):
    global MaxItemID, MinItemID, TransLengthMax, TransLengthMin, TransLengthMean, TransNum
    
    MaxItemID = 0
    MinItemID = float('inf')
    TransNum = 0
    TransLengthMax = 0
    TransLengthMin = float('inf')
    TransLengthMean = 0.0
    
    with open(TransSet, 'r') as infile:
        for line in infile:
            line = line.strip()
            if not line:
                continue
                
            transaction = []
            items = line.split()
            
            for item_str in items:
                item = int(item_str)
                transaction.append(item)
                
                if item < MinItemID:
                    MinItemID = item
                if item > MaxItemID:
                    MaxItemID = item
            
            trans_len = len(transaction)
            if trans_len < TransLengthMin:
                TransLengthMin = trans_len
            if trans_len > TransLengthMax:
                TransLengthMax = trans_len
            
            TransLengthMean += trans_len
            TransNum += 1
    
    if MinItemID == 0:
        MaxItemID += 1
    
    if TransNum > 0:
        TransLengthMean /= TransNum
    
    print(f"TransNum: {TransNum}")

def ExpandingOperation(NewOne: MFI):
    global MaximalPopulationMat, TransSetReducedRAM, TransNumReduced, TransNum, SupportThreshold, TransSetDimensionReduced
    
    SupportItem = [0.0] * (TransSetDimensionReduced + 1)
    SupportItem_temp = [0.0] * (TransSetDimensionReduced + 1)
    
    for TransID in range(TransNumReduced):
        find = 0
        SupportItem_temp = [0.0] * (TransSetDimensionReduced + 1)
        
        for i in range(1, TransSetReducedRAM[TransID][0] + 1):
            item_idx = TransSetReducedRAM[TransID][i]
            if NewOne.chromosome[item_idx] > 0:
                find += 1
            SupportItem_temp[item_idx] = 1.0
        
        if find == NewOne.number:
            for i in range(1, TransSetDimensionReduced + 1):
                if SupportItem_temp[i] > 0:
                    SupportItem[i] += 1.0
    
    FrequentNum = 0
    for i in range(1, TransSetDimensionReduced + 1):
        SupportItem[i] /= TransNum
        if SupportItem[i] >= SupportThreshold:
            FrequentNum += 1
    
    if FrequentNum == NewOne.number:
        MaximalPopulationMat[NewOne.root][0].number += 1
        idx = MaximalPopulationMat[NewOne.root][0].number
        MaximalPopulationMat[NewOne.root][idx] = NewOne
        
        print(f"{NewOne.root} -> [ ", end="")
        # for i in range(1, TransSetDimensionReduced + 1):
            # print(f"{NewOne.chromosome[i]} ", end="")
        print("]")
    else:
        for i in range(NewOne.progress + 1, TransSetDimensionReduced + 1):
            if SupportItem[i] >= SupportThreshold and NewOne.chromosome[i] == 0:
                SuperOne = MFI()
                SuperOne.chromosome = NewOne.chromosome.copy()
                SuperOne.chromosome[i] = 1
                SuperOne.number = NewOne.number + 1
                SuperOne.support = SupportItem[i]
                SuperOne.progress = i
                SuperOne.root = NewOne.root
                
                ExpandingOperation(SuperOne)

def main():
    global MaxItemID, MinItemID, TransLengthMax, TransLengthMin, TransLengthMean
    global TransSetReducedRAM, SupportThreshold, TransSetDimensionReduced
    global TransNum, TransNumReduced, MaximalPopulation, MaximalPopulationMat
    global MaximalPopulationSize
    
    tic = time.time()
    CPUTimePre = 0.0
    CPUTime = 0.0
    
    # ======================选择数据集========================
    TransSet = "chess.txt"; SupportThreshold = 0.95
    # TransSet = "connect.txt"; SupportThreshold = 0.965
    # TransSet = "mushroom.txt"; SupportThreshold = 0.52
    # TransSet = "T10I4D100K.txt"; SupportThreshold = 0.0225
    # TransSet = "retail.txt"; SupportThreshold = 0.00125
    
    # TransSet = "accidents.txt"; SupportThreshold = 0.5
    # TransSet = "pumsb_star.txt"; SupportThreshold = 0.275
    # TransSet = "pumsb.txt"; SupportThreshold = 0.8
    # TransSet = "T40I10D100K.txt"; SupportThreshold = 0.025
    # TransSet = "kosarak.txt"; SupportThreshold = 0.0024
    
    ItemStrIndex = "ItemIndex.txt"
    
    # 生成结果文件名
    OutputResult = f"python-{TransSet}-{SupportThreshold}=Result.txt"
    
    # 扫描事务集获取轮廓
    GetTransSetSize(TransSet)
    
    # 生成1维支持度
    Support1D = [0.0] * (MaxItemID + 1)
    
    with open(TransSet, 'r') as infile:
        for line in infile:
            line = line.strip()
            if not line:
                continue
                
            transaction = []
            items = line.split()
            for item_str in items:
                item = int(item_str)
                if MinItemID == 0:
                    item += 1
                transaction.append(item)
            
            for i in range(len(transaction)):
                item = transaction[i]
                IsRepeat = False
                for j in range(i):
                    if transaction[j] == item:
                        IsRepeat = True
                        break
                if not IsRepeat:
                    Support1D[item] += 1.0
    
    print("Support1D: ", end="")
    # for i in range(MaxItemID + 1):
        # print(f"{Support1D[i]} ", end="")
    print()
    
    # 计算精简维度
    TransSetDimensionReduced = 0
    for i in range(MaxItemID + 1):
        Support1D[i] /= TransNum
        if Support1D[i] >= SupportThreshold:
            TransSetDimensionReduced += 1
    
    if TransSetDimensionReduced == 0:
        print("\nTransSetDimensionReduced == 0, no result!")
        return
    
    print(f"TransSetDimensionReduced: {TransSetDimensionReduced}")
    
    # 生成精简1项集
    Support1DReduced = [0.0] * (TransSetDimensionReduced + 1)
    Support1DReducedItemIndex = [0] * (TransSetDimensionReduced + 1)
    Support1DReducedItemIndexReverse = [0.0] * (MaxItemID + 1)
    
    j = 0
    ItemSupportMin = 1.0
    ItemSupportMax = 0.0
    TransSetDimension = 0
    
    for i in range(1, MaxItemID + 1):
        if Support1D[i] >= SupportThreshold:
            j += 1
            Support1DReduced[j] = Support1D[i]
            Support1DReducedItemIndex[j] = i
            Support1DReducedItemIndexReverse[i] = j
        
        if 0 < Support1D[i] < ItemSupportMin:
            ItemSupportMin = Support1D[i]
        if Support1D[i] > ItemSupportMax:
            ItemSupportMax = Support1D[i]
        if Support1D[i] > 0:
            TransSetDimension += 1
    
    print("\nSupport1DReduced: ", end="")
    # for i in range(TransSetDimensionReduced + 1):
        # print(f"{Support1DReduced[i]} ", end="")
    print("\nSupport1DReducedItemIndex: ", end="")
    # for i in range(TransSetDimensionReduced + 1):
        # print(f"{Support1DReducedItemIndex[i]} ", end="")
    print("\nSupport1DReducedItemIndexReverse: ", end="")
    # for i in range(MaxItemID + 1):
        # print(f"{Support1DReducedItemIndexReverse[i]} ", end="")
    
    # 生成精简事务集文件
    TransSetReduced = "TransSetReduced.txt"
    TransNumReduced = 0
    TransLengthMaxReduced = 0
    TransLengthMinReduced = float('inf')
    TransLengthMeanReduced = 0.0
    
    with open(TransSet, 'r') as infile2, open(TransSetReduced, 'w') as outfile:
        for line in infile2:
            line = line.strip()
            if not line:
                continue
                
            transaction = []
            items = line.split()
            for item_str in items:
                item = int(item_str)
                if MinItemID == 0:
                    item += 1
                transaction.append(item)
            
            WriteTimes = 0
            output_items = []
            for i in range(len(transaction)):
                item = transaction[i]
                IsRepeat = False
                for j in range(i):
                    if transaction[j] == item:
                        IsRepeat = True
                        break
                
                if Support1D[item] >= SupportThreshold and not IsRepeat:
                    output_items.append(str(int(Support1DReducedItemIndexReverse[item])))
                    WriteTimes += 1
                    TransLengthMeanReduced += 1
            
            if WriteTimes > 0:
                outfile.write(" ".join(output_items) + "\n")
                TransNumReduced += 1
            
            if 0 < WriteTimes < TransLengthMinReduced:
                TransLengthMinReduced = WriteTimes
            if WriteTimes > TransLengthMaxReduced:
                TransLengthMaxReduced = WriteTimes
    
    if TransNumReduced > 0:
        TransLengthMeanReduced /= TransNumReduced
    
    TransSetSizeReductionRate = TransNumReduced * TransLengthMeanReduced / (TransNum * TransLengthMean)
    DimensionReductionRate = TransSetDimensionReduced / TransSetDimension
    
    # 读取精简事务集到内存
    TransSetReducedRAM = []
    
    with open(TransSetReduced, 'r') as infile3:
        for line in infile3:
            line = line.strip()
            if not line:
                continue
                
            items = line.split()
            transaction = [len(items)] + [int(item) for item in items]
            TransSetReducedRAM.append(transaction)
    
    print(f"\n\nTransNumReduced: {TransNumReduced}")
    print(f"TransSetDimensionReduced: {TransSetDimensionReduced}")
    print(f"TransLengthMaxReduced: {TransLengthMaxReduced}")
    print(f"TransLengthMinReduced: {TransLengthMinReduced}")
    print(f"TransLengthMeanReduced: {TransLengthMeanReduced}\n")
    
    # 计时
    toc = time.time()
    CPUTimePre = toc - tic
    
    MaximalPopulation = [MFI() for _ in range(TransNumReduced + 1)]
    MaximalPopulationMat = [None] * (TransSetDimensionReduced + 1)
    
    print("MFIs:")
    tic = time.time()
    
    # 主挖掘过程
    for i in range(1, TransSetDimensionReduced + 1):
        NewOne = MFI()
        NewOne.chromosome = [0] * (TransSetDimensionReduced + 1)
        NewOne.chromosome[i] = 1
        NewOne.number = 1
        NewOne.support = Support1DReduced[i]
        NewOne.progress = i
        NewOne.root = i
        
        MaximalPopulationMat[i] = [MFI() for _ in range(TransNumReduced + 1)]
        MaximalPopulationMat[i][0].number = 0
        
        ExpandingOperation(NewOne)
    
    toc = time.time()
    CPUTime = toc - tic
    
    # 整理MFI结果
    for i in range(1, TransSetDimensionReduced + 1):
        if MaximalPopulationMat[i][0].number == 0:
            continue
        for j in range(1, MaximalPopulationMat[i][0].number + 1):
            MaximalPopulation[MaximalPopulationSize] = MaximalPopulationMat[i][j]
            MaximalPopulationSize += 1
    
    # 解码项集
    ItemID = [0] * (MaxItemID + 1)
    ItemCode = [''] * (MaxItemID + 1)
    ItemStr = [''] * (MaxItemID + 1)
    
    with open(ItemStrIndex, 'r') as infile4:
        for i in range(1, MaxItemID + 1):
            try:
                parts = infile4.readline().strip().split()
                if len(parts) >= 3:
                    ItemID[i] = int(parts[0])
                    ItemCode[i] = parts[1]
                    ItemStr[i] = parts[2]
            except:
                pass
    
    for i in range(MaximalPopulationSize):
        TransLength = 0
        MaximalPopulation[i].ItemSets = [0] * (TransSetDimensionReduced + 1)
        MaximalPopulation[i].ItemSetsStr = [''] * (TransSetDimensionReduced + 1)
        
        for j in range(1, TransSetDimensionReduced + 1):
            if MaximalPopulation[i].chromosome[j] != 0:
                TransLength += 1
                item_idx = Support1DReducedItemIndex[j]
                MaximalPopulation[i].ItemSets[TransLength] = item_idx
                if item_idx < len(ItemStr):
                    MaximalPopulation[i].ItemSetsStr[TransLength] = ItemStr[item_idx]
        
        MaximalPopulation[i].times = int(MaximalPopulation[i].support * TransNum + 0.5)
    
    # 按支持度排序
    for i in range(MaximalPopulationSize - 1):
        for j in range(MaximalPopulationSize - i - 1):
            if MaximalPopulation[j].support < MaximalPopulation[j + 1].support:
                MaximalPopulation[j], MaximalPopulation[j + 1] = MaximalPopulation[j + 1], MaximalPopulation[j]
    
    # 生成结果文件
    with open(OutputResult, 'w') as outfile2:
        outfile2.write(f"TransSet: {TransSet}\n")
        outfile2.write(f"ItemStrIndex: {ItemStrIndex}\n\n")
        
        outfile2.write(f"MinItemID: {MinItemID}\n")
        outfile2.write(f"MaxItemID: {MaxItemID}\n")
        outfile2.write(f"TransNum: {TransNum}\n")
        outfile2.write(f"TransSetDimension: {TransSetDimension}\n")
        outfile2.write(f"TransLengthMin: {TransLengthMin}\n")
        outfile2.write(f"TransLengthMax: {TransLengthMax}\n")
        outfile2.write(f"TransLengthMean: {TransLengthMean}\n")
        outfile2.write(f"MinItemSupport: {ItemSupportMin}\n")
        outfile2.write(f"MaxItemSupport: {ItemSupportMax}\n")
        outfile2.write("\n")
        
        outfile2.write(f"SupportThreshold: {SupportThreshold}\n")
        outfile2.write("\n")
        
        outfile2.write(f"TransNumReduced: {TransNumReduced}\n")
        outfile2.write(f"TransSetDimensionReduced: {TransSetDimensionReduced}\n")
        outfile2.write(f"TransLengthMinReduced: {TransLengthMinReduced}\n")
        outfile2.write(f"TransLengthMaxReduced: {TransLengthMaxReduced}\n")
        outfile2.write(f"TransLengthMeanReduced: {TransLengthMeanReduced}\n")
        outfile2.write(f"TransSetSizeReductionRate: {TransSetSizeReductionRate}\n")
        outfile2.write(f"DimensionReductionRate: {DimensionReductionRate}\n")
        outfile2.write(f"TransSetReduced: {TransSetReduced}\n")
        outfile2.write("\n")
        
        outfile2.write(f"MaximalPopulationSize: {MaximalPopulationSize}\n")
        outfile2.write(f"OutputResult: {OutputResult}\n")
        outfile2.write(f"CPUTimePre: {CPUTimePre}s\n")
        outfile2.write(f"CPUTime: {CPUTime}s\n")
        outfile2.write("\n\n")
        
        for i in range(MaximalPopulationSize):
            outfile2.write(f"{i + 1}: {MaximalPopulation[i].number} {{ ")
            for j in range(1, MaximalPopulation[i].number + 1):
                item_val = MaximalPopulation[i].ItemSets[j]
                if MinItemID == 0:
                    item_val -= 1
                if j < MaximalPopulation[i].number:
                    outfile2.write(f"{item_val} ")
                else:
                    outfile2.write(f"{item_val}")
            outfile2.write(f" }}     support: {MaximalPopulation[i].support}     times: {int(MaximalPopulation[i].times)}     {{ ")
            for j in range(1, MaximalPopulation[i].number + 1):
                if j < MaximalPopulation[i].number:
                    outfile2.write(f"{MaximalPopulation[i].ItemSetsStr[j]},   ")
                else:
                    outfile2.write(f"{MaximalPopulation[i].ItemSetsStr[j]}")
            outfile2.write(" }\n")
        
        outfile2.write("\n")
    
    # 控制台输出结果
    print("\n//======以结果文件格式打印输出======\n")
    print(f"TransSet: {TransSet}")
    print(f"ItemStrIndex: {ItemStrIndex}\n")
    
    print(f"MinItemID: {MinItemID}")
    print(f"MaxItemID: {MaxItemID}")
    print(f"TransNum: {TransNum}")
    print(f"TransSetDimension: {TransSetDimension}")
    print(f"TransLengthMin: {TransLengthMin}")
    print(f"TransLengthMax: {TransLengthMax}")
    print(f"TransLengthMean: {TransLengthMean}")
    print(f"MinItemSupport: {ItemSupportMin}")
    print(f"MaxItemSupport: {ItemSupportMax}")
    print()
    
    print(f"SupportThreshold: {SupportThreshold}")
    print()
    
    print(f"TransNumReduced: {TransNumReduced}")
    print(f"TransSetDimensionReduced: {TransSetDimensionReduced}")
    print(f"TransLengthMinReduced: {TransLengthMinReduced}")
    print(f"TransLengthMaxReduced: {TransLengthMaxReduced}")
    print(f"TransLengthMeanReduced: {TransLengthMeanReduced}")
    print(f"TransSetSizeReductionRate: {TransSetSizeReductionRate}")
    print(f"DimensionReductionRate: {DimensionReductionRate}")
    print(f"TransSetReduced: {TransSetReduced}")
    print()
    
    print(f"MaximalPopulationSize: {MaximalPopulationSize}")
    print(f"OutputResult: {OutputResult}")
    print(f"CPUTimePre: {CPUTimePre}s")
    print(f"CPUTime: {CPUTime}s")
    print("\n")
    
    for i in range(MaximalPopulationSize):
        print(f"{i + 1}: {MaximalPopulation[i].number} {{ ", end="")
        for j in range(1, MaximalPopulation[i].number + 1):
            item_val = MaximalPopulation[i].ItemSets[j]
            if MinItemID == 0:
                item_val -= 1
            if j < MaximalPopulation[i].number:
                print(f"{item_val} ", end="")
            else:
                print(f"{item_val}", end="")
        print(f" }}     support: {MaximalPopulation[i].support}     times: {int(MaximalPopulation[i].times)}     {{ ", end="")
        for j in range(1, MaximalPopulation[i].number + 1):
            if j < MaximalPopulation[i].number:
                print(f"{MaximalPopulation[i].ItemSetsStr[j]},   ", end="")
            else:
                print(f"{MaximalPopulation[i].ItemSetsStr[j]}", end="")
        print(" }")
    
    print()
    return 0

if __name__ == "__main__":
    main()
