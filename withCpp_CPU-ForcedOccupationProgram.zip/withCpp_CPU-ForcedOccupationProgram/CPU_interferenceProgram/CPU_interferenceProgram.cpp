﻿#include <iostream>
#include <windows.h>
#include <chrono>
#include <thread>
#include <vector>
#include <cmath>

//=================在这里修改目标整机CPU利用率=================
double targetTotalPercent = 30.0;//（%）

//==============================================================================CPU强制占用
void LoadWorker(double perCoreTargetPercent, DWORD coreId)
{
    // 设置线程亲和性：绑定到指定逻辑核
    HANDLE hThread = GetCurrentThread();
    DWORD_PTR affinityMask = 1ULL << coreId;
    SetThreadAffinityMask(hThread, affinityMask);

    // 提升线程优先级：THREAD_PRIORITY_HIGHEST
    SetThreadPriority(hThread, THREAD_PRIORITY_HIGHEST);

    const int cycleMs = 20;
    double busyRatio = perCoreTargetPercent / 100.0;
    int busyMs = static_cast<int>(cycleMs * busyRatio);
    int sleepMs = cycleMs - busyMs;

    while (true)
    {
        auto start = std::chrono::high_resolution_clock::now();
        while (std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::high_resolution_clock::now() - start).count() < busyMs)
        {
        }
        if (sleepMs > 0)
        {
            Sleep(sleepMs);
        }
    }
}

int GetLogicalCpuCount()
{
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    return (int)sysInfo.dwNumberOfProcessors;
}

int main()
{
    // 提升进程整体优先级
    HANDLE hProcess = GetCurrentProcess();
    SetPriorityClass(hProcess, HIGH_PRIORITY_CLASS);

    int logicCores = GetLogicalCpuCount();
    std::cout << "本机逻辑CPU核心数：" << logicCores << std::endl;

    // =====================================================

    if (targetTotalPercent <= 0 || targetTotalPercent > 100)
    {
        std::cout << "百分比范围0~100！" << std::endl;
        return -1;
    }

    int threadNum = static_cast<int>(ceil(targetTotalPercent / 100.0 * logicCores));
    if (threadNum > logicCores) threadNum = logicCores;

    std::cout << "创建 " << threadNum << " 个高优先级负载线程，绑定到独立逻辑核\n";
    std::cout << "预期整机负载：" << (threadNum * 100.0 / logicCores) << " %\n";

    std::vector<std::thread> threads;
    for (int i = 0; i < threadNum; i++)
    {
        threads.emplace_back(LoadWorker, 100.0, (DWORD)i);
    }

    for (auto& t : threads)
    {
        t.join();
    }
    return 0;
}

//==============================================================================CPU非强制占用
/*void LoadWorker(double perCoreTargetPercent)
{
    const int cycleMs = 20;
    double busyRatio = perCoreTargetPercent / 100.0;
    int busyMs = static_cast<int>(cycleMs * busyRatio);
    int sleepMs = cycleMs - busyMs;

    while (true)
    {
        auto start = std::chrono::high_resolution_clock::now();
        while (std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::high_resolution_clock::now() - start).count() < busyMs)
        {
        }
        if (sleepMs > 0)
        {
            Sleep(sleepMs);
        }
    }
}

int GetLogicalCpuCount()
{
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    return (int)sysInfo.dwNumberOfProcessors;
}

int main()
{
    int logicCores = GetLogicalCpuCount();
    std::cout << "本机逻辑CPU核心数：" << logicCores << std::endl;

    //=============================================================

    if (targetTotalPercent <= 0 || targetTotalPercent > 100)
    {
        std::cout << "百分比范围0~100！" << std::endl;
        return -1;
    }

    int threadNum = static_cast<int>(ceil(targetTotalPercent / 100.0 * logicCores));
    double perCoreLoad = 100.0;

    if (threadNum > logicCores) threadNum = logicCores;

    std::cout << "将创建 " << threadNum << " 个负载线程，每个线程占满单个逻辑核" << std::endl;
    std::cout << "预期整机负载：" << (threadNum * 100.0 / logicCores) << " %\n";

    std::vector<std::thread> threads;
    for (int i = 0; i < threadNum; i++)
    {
        threads.emplace_back(LoadWorker, perCoreLoad);
    }

    for (auto& t : threads)
    {
        t.join();
    }
    return 0;
}*/
