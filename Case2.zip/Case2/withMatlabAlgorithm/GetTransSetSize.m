%��ȡ��Ʒ�����С���========
function [MaxItemID,MinItemID,TransactionsNum,TransLengthMean,TransLengthMax,TransLengthMin]=GetTransSetSize(TransSet)

OpenFile=fopen(TransSet,'r');
MaxItemID=0;   
MinItemID=realmax;   
TransLengthMax=0;   
TransLengthMin=realmax;  
TransLengthMean=0;
Prescan=0;
while~feof(OpenFile)%�ж��Ƿ�Ϊ�ļ�ĩβ
    line=fgetl(OpenFile);
    NumList=str2num(line);
    LineLength=numel(NumList);
    for i=1:LineLength  
        if NumList(i)<MinItemID
            MinItemID=NumList(i);
        end
        if NumList(i)>MaxItemID
            MaxItemID=NumList(i);
        end
    end
    if LineLength<TransLengthMin
        TransLengthMin=LineLength;
    end
    if LineLength>TransLengthMax
        TransLengthMax=LineLength;
    end
    clear line;
    clear NumList; 
    TransLengthMean=TransLengthMean+LineLength;
    Prescan=Prescan+1;    
end
fclose(OpenFile);
TransactionsNum=Prescan;
TransLengthMean=TransLengthMean/TransactionsNum;
if MinItemID==0
    MaxItemID=MaxItemID+1;
end
