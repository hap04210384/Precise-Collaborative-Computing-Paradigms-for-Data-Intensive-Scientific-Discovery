tic;
clc;
clear;
close all;

TransSet='chess.txt'; SupportThreshold=0.95;
%TransSet='connect.txt'; SupportThreshold=0.965;
%TransSet='mushroom.txt'; SupportThreshold=0.52;
%TransSet='T10I4D100K.txt'; SupportThreshold=0.0225;
%TransSet='retail.txt'; SupportThreshold=0.00125;

%TransSet='accidents.txt'; SupportThreshold=0.5;
%TransSet='pumsb_star.txt'; SupportThreshold=0.275;
%TransSet='pumsb.txt'; SupportThreshold=0.8;
%TransSet='T40I10D100K.txt'; SupportThreshold=0.025;
%TransSet='kosarak.txt'; SupportThreshold=0.0024;

ItemStrIndex='ItemIndex.txt';
[MaxItemID,MinItemID,TransNum,TransLengthMean,TransLengthMax,TransLengthMin]=GetTransSetSize(TransSet);%��ɨ��ķ�ʽ��ȡ��������

Support1D=zeros(1,MaxItemID);%ɨ����������1ά֧�ֶ�
FirstScanTransSet=0;
TransSetHandle=fopen(TransSet,'r');
while~feof(TransSetHandle)
    line=fgetl(TransSetHandle);
    NumList=str2num(line); 
    LineLength=numel(NumList);
    for i=1:LineLength
        if MinItemID==0
            NumList(i)=NumList(i)+1;
        end
        IsRepeat=0;
        for j=1:i-1
            if NumList(i)==NumList(j)
                IsRepeat=1;
            end     
        end
        if IsRepeat==0
            Support1D(NumList(i))=Support1D(NumList(i))+1;
        end
    end
    FirstScanTransSet=FirstScanTransSet+1;
end

TransSetDimensionReduced=0;%��ȡSupport1DReduced���ȣ�֧�ֶȹ�һ����
for i=1:MaxItemID    
    Support1D(i)=Support1D(i)/TransNum;
    if Support1D(i)>=SupportThreshold
        TransSetDimensionReduced=TransSetDimensionReduced+1;
    end
end
if TransSetDimensionReduced==0
    TransSetDimensionReduced;
    return;
end

Support1DReduced=zeros(1,TransSetDimensionReduced);%���ɾ���1�
Support1DReducedItemIndex=zeros(1,TransSetDimensionReduced);
Support1DReducedItemIndexReverse=zeros(1,MaxItemID);
j=0;
ItemSupportMin=1;
ItemSupportMax=0;
TransSetDimension=0;
for i=1:MaxItemID
    if Support1D(i)>=SupportThreshold
        j=j+1;
        Support1DReduced(j)=Support1D(i);
        Support1DReducedItemIndex(j)=i;
        Support1DReducedItemIndexReverse(i)=j;
    end
    if Support1D(i)<ItemSupportMin&&Support1D(i)>0
        ItemSupportMin=Support1D(i);
    end
    if Support1D(i)>ItemSupportMax
        ItemSupportMax=Support1D(i);
    end
    if Support1D(i)>0
        TransSetDimension=TransSetDimension+1;
    end
end

TransSetReduced='TransSetReduced.txt';%ɨ���������ɾ��������ļ���ʹ����ItemID
TransSetHandle=fopen(TransSet,'r');
TransSetReducedHandle=fopen(TransSetReduced,'w');
SecondScanTransSet=0;
TransNumReduced=0;
TransLengthMaxReduced=0;   
TransLengthMinReduced=realmax;  
TransLengthMeanReduced=0;
while~feof(TransSetHandle)
    line=fgetl(TransSetHandle);
    NumList=str2num(line);
    LineLength=numel(NumList);  
    WriteTimes=0;
    for i=1:LineLength         
        if MinItemID==0
            NumList(i)=NumList(i)+1;
        end
        IsRepeat=0;
        for j=1:i-1
            if NumList(i)==NumList(j)
                IsRepeat=1;
            end     
        end
        if (Support1D(NumList(i))>=SupportThreshold)&&(IsRepeat==0)
            fprintf(TransSetReducedHandle,'%d',Support1DReducedItemIndexReverse(NumList(i)));
            if i<LineLength
                fprintf(TransSetReducedHandle,' ');
            end
            WriteTimes=WriteTimes+1;
            TransLengthMeanReduced=TransLengthMeanReduced+1;
        end
    end
    if WriteTimes>0
        fprintf(TransSetReducedHandle,'\n');
        TransNumReduced=TransNumReduced+1;
    end
    if (WriteTimes<TransLengthMinReduced)&&(WriteTimes>0)
        TransLengthMinReduced=WriteTimes;
    end
    if WriteTimes>TransLengthMaxReduced
        TransLengthMaxReduced=WriteTimes;
    end
    SecondScanTransSet=SecondScanTransSet+1;
end
TransLengthMeanReduced=TransLengthMeanReduced/TransNumReduced;
TransSetSizeReductionRate=TransNumReduced*TransLengthMeanReduced/TransNum/TransLengthMean;
DimensionReductionRate=TransSetDimensionReduced/TransSetDimension;
fclose(TransSetHandle);
fclose(TransSetReducedHandle);

TransSetReducedRAM=zeros(TransNumReduced,TransSetDimensionReduced+1);  %ɨ�辫�����������ڴ����
TransSetReducedHandle=fopen(TransSetReduced,'r');
ThirdScanTransSet=0;
while~feof(TransSetReducedHandle)
    ThirdScanTransSet=ThirdScanTransSet+1;
    line=fgetl(TransSetHandle);
    NumList=str2num(line);
    LineLength=numel(NumList); 
    for i=1:LineLength
        TransSetReducedRAM(ThirdScanTransSet,i)=NumList(i);
    end
    TransSetReducedRAM(ThirdScanTransSet,TransSetDimensionReduced+1)=LineLength;
end
fclose(TransSetReducedHandle);

CPUTimePre=toc;
tic;
MaximalPopulationSize=0;  %����
for i=1:TransSetDimensionReduced  
    NewOne.chromosome=zeros(1,TransSetDimensionReduced);
    NewOne.chromosome(i)=1;
    NewOne.number=1;
    NewOne.support=Support1DReduced(i);
    NewOne.progress=i;
    
    GroupSize=0;
    [MaximalGroup,GroupSize]=ExpandingOperation(NewOne,TransSetReducedRAM,SupportThreshold,TransSetDimensionReduced,TransNum,TransNumReduced);
    if GroupSize>0
        for j=1:GroupSize
            MaximalPopulation(MaximalPopulationSize+j)=MaximalGroup(j);
        end
        MaximalPopulationSize=MaximalPopulationSize+GroupSize;
    end
end
CPUTime=toc;

[ItemID,ItemCode,ItemStr] = textread(ItemStrIndex,'%s %s %s');
for i=1:MaximalPopulationSize  %����
    TransLength=0;
    for j=1:TransSetDimensionReduced
        if MaximalPopulation(i).chromosome(j)~=0
            TransLength=TransLength+1;
            MaximalPopulation(i).ItemSets(TransLength)=Support1DReducedItemIndex(j);
            MaximalPopulation(i).ItemSetsStr(TransLength)=ItemStr(Support1DReducedItemIndex(j));
        end
    end
    MaximalPopulation(i).times=round(MaximalPopulation(i).support*TransNum);
end

for i=1:MaximalPopulationSize-1  % sorting by support
    for j=1:MaximalPopulationSize-i
        if MaximalPopulation(j).support<MaximalPopulation(j+1).support
            ExOne=MaximalPopulation(j);
            MaximalPopulation(j)=MaximalPopulation(j+1);
            MaximalPopulation(j+1)=ExOne;
        end
    end
end

OutputResult=sprintf('ThinkStation-Matlab-Result-%s-%f.txt',TransSet,SupportThreshold);  %���ɽ���ļ�
OutputResultHandle=fopen(OutputResult,'w');

fprintf(OutputResultHandle,'TransSet: "%s"\n',TransSet);
fprintf(OutputResultHandle,'ItemStrIndex: "%s"\n',ItemStrIndex);

fprintf(OutputResultHandle,'\n');
fprintf(OutputResultHandle,'MinItemID: %d\n',MinItemID);
fprintf(OutputResultHandle,'MaxItemID: %d\n',MaxItemID);
fprintf(OutputResultHandle,'TransNum: %d\n',TransNum);
fprintf(OutputResultHandle,'TransSetDimension: %d\n',TransSetDimension);
fprintf(OutputResultHandle,'TransLengthMin: %d\n',TransLengthMin);
fprintf(OutputResultHandle,'TransLengthMax: %d\n',TransLengthMax);
fprintf(OutputResultHandle,'TransLengthMean: %f\n',TransLengthMean);
fprintf(OutputResultHandle,'MinItemSupport: %f\n',ItemSupportMin);
fprintf(OutputResultHandle,'MaxItemSupport: %f\n',ItemSupportMax);
fprintf(OutputResultHandle,'\n');

fprintf(OutputResultHandle,'SupportThreshold: %f\n',SupportThreshold);

fprintf(OutputResultHandle,'\n');
fprintf(OutputResultHandle,'TransNumReduced: %d\n',TransNumReduced);
fprintf(OutputResultHandle,'TransSetDimensionReduced: %d\n',TransSetDimensionReduced);
fprintf(OutputResultHandle,'TransLengthMinReduced: %d\n',TransLengthMinReduced);
fprintf(OutputResultHandle,'TransLengthMaxReduced: %d\n',TransLengthMaxReduced);
fprintf(OutputResultHandle,'TransLengthMeanReduced: %f\n',TransLengthMeanReduced);
fprintf(OutputResultHandle,'TransSetSizeReductionRate: %f\n',TransSetSizeReductionRate);
fprintf(OutputResultHandle,'DimensionReductionRate: %f\n',DimensionReductionRate);
fprintf(OutputResultHandle,'TransSetReduced: "%s"\n',TransSetReduced);

fprintf(OutputResultHandle,'\n');
fprintf(OutputResultHandle,'MaximalPopulationSize: %d\n',MaximalPopulationSize);
fprintf(OutputResultHandle,'OutputResult: "%s"\n',OutputResult);
fprintf(OutputResultHandle,'CPUTimePre: %fs\n',CPUTimePre);
fprintf(OutputResultHandle,'CPUTime: %fs\n',CPUTime);
fprintf(OutputResultHandle,'\n');
fprintf(OutputResultHandle,'\n');

for i=1:MaximalPopulationSize
    fprintf(OutputResultHandle,'%d: %d { ',i,MaximalPopulation(i).number);
    for j=1:MaximalPopulation(i).number
        if MinItemID==0
            MaximalPopulation(i).ItemSets(j)=MaximalPopulation(i).ItemSets(j)-1;
        end
        if j<MaximalPopulation(i).number
            fprintf(OutputResultHandle,'%d ',MaximalPopulation(i).ItemSets(j));
        else
            fprintf(OutputResultHandle,'%d',MaximalPopulation(i).ItemSets(j));
        end
    end
    fprintf(OutputResultHandle,' }     support: %f     times: %d     { ',MaximalPopulation(i).support,MaximalPopulation(i).times);
    for j=1:MaximalPopulation(i).number
        if j<MaximalPopulation(i).number
            fprintf(OutputResultHandle,'%s,   ',MaximalPopulation(i).ItemSetsStr{1,j});
        else
            fprintf(OutputResultHandle,'%s',MaximalPopulation(i).ItemSetsStr{1,j});
        end 
    end
    fprintf(OutputResultHandle,' }\n');
end
fclose(OutputResultHandle);

toc;
clear ans;
clear TransSetHandle;
clear TransSetReducedHandle;
clear OutputResultHandle;
clear RunForSupport1D;
clear GroupSize;
clear i;
clear j;
clear line;
clear Lline;
clear NewOne;
clear LineLength;
clear NumList;
clear MaximalGroup;
clear WriteTimes;
clear ExOne;
clear IsRepeat;
clear TransLength;
clear TranID;

figure;
subplot(2,1,1),bar(Support1D),title('Support1D');
subplot(2,1,2),bar(Support1DReduced),title('Support1DReduced');

