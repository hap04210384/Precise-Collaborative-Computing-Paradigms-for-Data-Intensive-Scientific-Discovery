function [MaximalGroup,GroupSize]=ExpandingOperation(NewOne,TranSetReducedRAM,SupportThreshold,Support1DReducedLength,TransactionsNum,TransNumReduced)
%NewOne.chromosome
SupportItem=zeros(1,Support1DReducedLength);
for TrandID=1:TransNumReduced
    find=0;
    SupportItem_temp=zeros(1,Support1DReducedLength);
    for i=1:TranSetReducedRAM(TrandID,Support1DReducedLength+1)
        if NewOne.chromosome(TranSetReducedRAM(TrandID,i))~=0
            find=find+1;
        end
        SupportItem_temp(TranSetReducedRAM(TrandID,i))=1;
    end
    if find==NewOne.number          
         for i=1:Support1DReducedLength  
             if SupportItem_temp(i)~=0
                 SupportItem(i)=SupportItem(i)+1;
             end
         end
    end
end

FrequentNum=0;
for i=1:Support1DReducedLength
    SupportItem(i)=SupportItem(i)/TransactionsNum;
    if SupportItem(i)>=SupportThreshold
        FrequentNum=FrequentNum+1; 
    end
end

GroupSize=0;
MaximalGroup(1)=NewOne;
if FrequentNum==NewOne.number
    NewOne.chromosome
    GroupSize=GroupSize+1;
else
    for i=NewOne.progress+1:Support1DReducedLength
        if (SupportItem(i)>=SupportThreshold)&&(NewOne.chromosome(i)==0)
            SuperOne=NewOne;
            SuperOne.chromosome(i)=1;
            SuperOne.number=SuperOne.number+1;
            SuperOne.support=SupportItem(i);
            SuperOne.progress=i;
            GroupSizeNest=0;
            [MaximalGroupNest,GroupSizeNest]=ExpandingOperation(SuperOne,TranSetReducedRAM,SupportThreshold,Support1DReducedLength,TransactionsNum,TransNumReduced);
            if GroupSizeNest>0                     
                for j=1:GroupSizeNest           
                    MaximalGroup(GroupSize+j)=MaximalGroupNest(j);        
                end          
                GroupSize=GroupSize+GroupSizeNest;
            end
        end
    end
end
 




