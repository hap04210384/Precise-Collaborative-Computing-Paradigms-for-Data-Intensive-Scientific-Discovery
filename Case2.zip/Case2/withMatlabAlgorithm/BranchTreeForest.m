clear;
close all;
w=10;
h=10;

figure;
plot([1,1],[1,h],'w','linewidth',1);hold on;
plot([1,w],[1,1],'w','linewidth',1);hold on;
plot(2,9,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([2,3],[9,8],'b','linewidth',1);
plot(3,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([3,6],[8,7],'b','linewidth',1);
plot(6,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([6,7],[7,6],'b','linewidth',1);
plot(7,6,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([7,9],[6,5],'b','linewidth',1);
plot(9,5,'bo','MarkerFaceColor','b','MarkerSize',10);
grid on;

figure;
plot([1,1],[1,h],'w','linewidth',1);hold on;
plot([1,w],[1,1],'w','linewidth',1);hold on;

plot([2,7],[9,8],'r','linewidth',1);
plot(7,8,'ro','MarkerFaceColor','r','MarkerSize',10);
plot([7,8],[8,7],'r','linewidth',1);
plot(8,7,'ro','MarkerFaceColor','r','MarkerSize',10);

plot([3,4],[8,7],'r','linewidth',1);
plot(4,7,'ro','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[7,6],'r','linewidth',1);
plot(5,6,'ro','MarkerFaceColor','r','MarkerSize',10);

plot(2,9,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([2,3],[9,8],'b','linewidth',1);
plot(3,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([3,6],[8,7],'b','linewidth',1);
plot(6,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([6,7],[7,6],'b','linewidth',1);
plot(7,6,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([7,9],[6,5],'b','linewidth',1);
plot(9,5,'bo','MarkerFaceColor','b','MarkerSize',10);
grid on;

figure;
plot([1,1],[1,h],'w','linewidth',1);hold on;
plot([1,w],[1,1],'w','linewidth',1);hold on;

plot(3,9,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([3,4],[9,8],'g','linewidth',1);
% plot(4,8,'go','MarkerFaceColor','g','MarkerSize',10);

plot(4,9,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([4,5],[9,8],'g','linewidth',1);
% plot(5,8,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([5,6],[8,7],'g','linewidth',1);
% plot(6,7,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([5,7],[8,7],'g','linewidth',1);
% plot(7,7,'go','MarkerFaceColor','g','MarkerSize',10);

plot(5,9,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([5,6],[9,8],'g','linewidth',1);
% plot(6,8,'go','MarkerFaceColor','g','MarkerSize',10);

plot(6,9,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([6,7],[9,8],'g','linewidth',1);
% plot(7,8,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([7,8],[8,7],'g','linewidth',1);
% plot(8,7,'go','MarkerFaceColor','g','MarkerSize',10);

plot(7,9,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([7,8],[9,8],'g','linewidth',1);
% plot(8,8,'go','MarkerFaceColor','g','MarkerSize',10);

plot(8,9,'go','MarkerFaceColor','g','MarkerSize',10);
% plot([8,9],[9,8],'g','linewidth',1);
% plot(9,8,'go','MarkerFaceColor','g','MarkerSize',10);

plot(9,9,'go','MarkerFaceColor','g','MarkerSize',10);

plot([2,7],[9,8],'r','linewidth',1);
plot(7,8,'ro','MarkerFaceColor','r','MarkerSize',10);
plot([7,8],[8,7],'r','linewidth',1);
plot(8,7,'ro','MarkerFaceColor','r','MarkerSize',10);

plot([3,4],[8,7],'r','linewidth',1);
plot(4,7,'ro','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[7,6],'r','linewidth',1);
plot(5,6,'ro','MarkerFaceColor','r','MarkerSize',10);

plot(2,9,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([2,3],[9,8],'b','linewidth',1);
plot(3,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([3,6],[8,7],'b','linewidth',1);
plot(6,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([6,7],[7,6],'b','linewidth',1);
plot(7,6,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([7,9],[6,5],'b','linewidth',1);
plot(9,5,'bo','MarkerFaceColor','b','MarkerSize',10);
grid on;

figure;
plot([1,1],[1,h],'w','linewidth',1);hold on;
plot([1,w],[1,1],'w','linewidth',1);hold on;
plot(2,9,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(3,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(4,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(5,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(6,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(7,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(8,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(9,8,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([2,3],[9,8],'b','linewidth',1);
plot([2,4],[9,8],'b','linewidth',1);
plot([2,5],[9,8],'b','linewidth',1);
plot([2,6],[9,8],'b','linewidth',1);
plot([2,7],[9,8],'b','linewidth',1);
plot([2,8],[9,8],'b','linewidth',1);
plot([2,9],[9,8],'b','linewidth',1);
plot(5,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(6,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(7,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(8,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot(9,7,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[8,7],'b','linewidth',1);
plot([4,6],[8,7],'b','linewidth',1);
plot([4,7],[8,7],'b','linewidth',1);
plot([4,8],[8,7],'b','linewidth',1);
plot([4,9],[8,7],'b','linewidth',1);
plot(8,6,'bo','MarkerFaceColor','b','MarkerSize',10);
plot([7,8],[7,6],'b','linewidth',1);
grid on;
