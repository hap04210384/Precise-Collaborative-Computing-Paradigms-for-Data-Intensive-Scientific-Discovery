clear;
close all;

x1=[42,106,212,328,431];
y1=[239,1054,2962,6714,12656];
plot(x1,y1,'or');

x2 = min(x1):1:max(x1);
y2 = interp1(x1,y1,x2,'pchip');
hold on;
plot(x2,y2);

x3 = min(x1):1:50;
e = 2;
y3 = power(e,x3)/power(e,x1(1))*y1(1);
hold on;
plot(x3,y3);

xlabel('Dimension');
ylabel('Algorithm running time(s), Solution space size');
legend('Algorithm running time(s)',' ','Solution space size');




% legend('Average number of items','Number of items that can be added');
% figure;
% hold on;
% plot(x2,y2);
% hold on;
% plot(x3,y3);
% legend('Number of non-frequent itemsets','Number of frequent itemsets');

